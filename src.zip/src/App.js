import React from 'react';
import './App.css';

const data = {
  "pricelist": [
  {
  "piece": {"name": "Bottle", "quantity": 1, "price": 410},
  "pack": {"name": "11-pack", "quantity": 11, "price": 4000},
  "box": {"name": "Big box", "quantity": 264, "price": 950}
  },
  {
  "piece": {"name": "Chocolade bar", "quantity": 1, "price": 300},
  "pack": {"name": "Chocolade pack", "quantity": 5, "price": 1450}
  },
  {
  "piece": {"name": "Biscuit", "quantity": 3, "price": 450}
  }
  ]
  }

  
function App() {
  return (
    <div className="App">
      <header className="App-header">Price Optimizer</header>
      <h3>Price List</h3>
      <ul>
  
      data.pricelist.map((key) => (( Object.entries(key)))
  )
  )
        data.pricelist.map(price) => {
        <li>
        <span>{name}</span> 
        <span>{quanutity}</span>
        <span>{price}</span>
        </li>
        }
      </ul>
    </div>
  );
}

export default App;
