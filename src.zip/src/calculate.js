const calculate = (n, prices, pieces) => {

    let piece = n;
    let bags = 0;
    let packs = 0;
    
    if (piece >= pieces[2]) {
        bags = Math.trunc(piece / pieces[2]);
        piece= piece % pieces[2]
    }
    if (piece >= pieces[1]) {
        packs= Math.trunc(piece / pieces[1])
        piece = piece % pieces[1]
    }
    
    return ([piece, packs, bags])
    }
    
    